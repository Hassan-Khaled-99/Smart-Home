/*
 * SPI_Slave_Configuration.h
 *
 * Created: 2/9/2023 10:46:44 AM
 *  Author: eng.m.nagy
 */ 


#ifndef SPI_SLAVE_CONFIGURATION_H_
#define SPI_SLAVE_CONFIGURATION_H_

#include "CPU_Configuration.h"


#define SPI_SCK  7
#define SPI_MISO 6
#define SPI_MOSI 5
#define SPI_SS   4



#endif /* SPI_SLAVE_CONFIGURATION_H_ */