/*
 * Timer_Slave_Configuration.h
 *
 * Created: 2/9/2023 10:48:07 AM
 *  Author: eng.m.nagy
 */ 


#ifndef TIMER_SLAVE_CONFIGURATION_H_
#define TIMER_SLAVE_CONFIGURATION_H_


#include "CPU_Configuration.h"


#endif /* TIMER_SLAVE_CONFIGURATION_H_ */