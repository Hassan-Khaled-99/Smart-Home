/*
 * ADC_Slave_Configuration.h
 *
 * Created: 2/9/2023 10:45:45 AM
 *  Author: eng.m.nagy
 */ 


#ifndef ADC_SLAVE_CONFIGURATION_H_
#define ADC_SLAVE_CONFIGURATION_H_

#include "CPU_Configuration.h"



#endif /* ADC_SLAVE_CONFIGURATION_H_ */