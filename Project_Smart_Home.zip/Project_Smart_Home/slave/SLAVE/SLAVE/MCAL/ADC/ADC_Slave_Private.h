/*
 * ADC_Slave_Private.h
 *
 * Created: 2/9/2023 10:45:22 AM
 *  Author: eng.m.nagy
 */ 


#ifndef ADC_SLAVE_PRIVATE_H_
#define ADC_SLAVE_PRIVATE_H_

#include "ADC_Slave_Configuration.h"


/*
	Function Name        : ADC_vinit
	Function Returns     : void
	Function Arguments   : void
	Function Description : Initialize the ADC.
*/
void ADC_vinit(void);

/*
	Function Name        : ADC_u16Read
	Function Returns     : uint16
	Function Arguments   : void
	Function Description : Read the value which converted by the ADC.
*/
uint16 ADC_u16Read(void);

#endif /* ADC_SLAVE_PRIVATE_H_ */