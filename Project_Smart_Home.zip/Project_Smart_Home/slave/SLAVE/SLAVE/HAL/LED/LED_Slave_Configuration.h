/*
 * LED_Slave_Configuration.h
 *
 * Created: 2/9/2023 10:30:18 AM
 *  Author: eng.m.nagy
 */ 


#ifndef LED_SLAVE_CONFIGURATION_H_
#define LED_SLAVE_CONFIGURATION_H_

#include "CPU_Configuration.h"




#define ROOM1_LED_PORT			  'D'
#define ROOM2_LED_PORT			  'D'
#define ROOM3_LED_PORT			  'D'
#define ROOM4_LED_PORT			  'D'
#define TV_LED_PORT				  'D'
#define AIR_CONDITIONING_LED_PORT 'D'

#define ROOM1_LED_PIN			   0
#define ROOM2_LED_PIN			   1
#define ROOM3_LED_PIN			   2
#define ROOM4_LED_PIN			   3
#define TV_LED_PIN				   4
#define AIR_CONDITIONING_LED_PIN   5




#endif /* LED_SLAVE_CONFIGURATION_H_ */