/*
 * main.h
 *
 * Created: 2/9/2023 10:21:04 AM
 *  Author: eng.m.nagy
 */ 


#ifndef MAIN_H_
#define MAIN_H_

#include "SPI_Slave_Private.h"
#include "STD_type.h"
#include "DIO_Slave_Private.h"
#include "LED_Slave_Private.h"
#include "ADC_Slave_Private.h"
#include "Timer_Slave_Private.h"
#include "CPU_Configuration.h"
//#include ""



#endif /* MAIN_H_ */