/*
 * Key_PAD_Private.h
 *
 * Created: 2/8/2023 1:18:46 PM
 *  Author: eng.m.nagy
 */ 


#ifndef KEY_PAD_PRIVATE_H_
#define KEY_PAD_PRIVATE_H_

#define NOT_PRESSED   0xff

#include "Key_PAD_Configuration.h"


/*
	Function Name        : keypad_vInit
	Function Returns     : void
	Function Arguments   : void
	Function Description : Initialize the keypad.
*/
void keypad_vInit(void);

/*
	Function Name        : keypad_u8check_press
	Function Returns     : uint8
	Function Arguments   : void
	Function Description : Returns the pressed key or return NOT_PRESSED if no keys are pressed.
*/
uint8 keypad_u8check_press(void);



#endif /* KEY_PAD_PRIVATE_H_ */