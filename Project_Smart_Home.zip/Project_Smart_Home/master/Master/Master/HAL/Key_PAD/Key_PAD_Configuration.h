/*
 * Key_PAD_Configuration.h
 *
 * Created: 2/8/2023 1:19:09 PM
 *  Author: eng.m.nagy
 */ 


#ifndef KEY_PAD_CONFIGURATION_H_
#define KEY_PAD_CONFIGURATION_H_

#include "CPU_Configuration.h"


/* keypad Macros */
#define KEYPAD_PORT			(uint8)'D'
#define KEYPAD_FIRST_PIN	(uint8)0
#define KEYPAD_SECOND_PIN	(uint8)1
#define KEYPAD_THIRD_PIN	(uint8)2
#define KEYPAD_FOURTH_PIN	(uint8)3
#define KEYPAD_FIFTH_PIN	(uint8)4
#define KEYPAD_SIXTH_PIN	(uint8)5
#define KEYPAD_SEVENTH_PIN	(uint8)6
#define KEYPAD_EIGHTH_PIN	(uint8)7



#endif /* KEY_PAD_CONFIGURATION_H_ */