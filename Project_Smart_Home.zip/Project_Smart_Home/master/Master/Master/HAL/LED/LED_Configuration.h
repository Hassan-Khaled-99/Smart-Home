/*
 * LED_Configuration.h
 *
 * Created: 2/8/2023 12:40:58 PM
 *  Author: eng.m.nagy
 */ 


#ifndef LED_CONFIGURATION_H_
#define LED_CONFIGURATION_H_

#include "CPU_Configuration.h"

/*****************************  Ports and pins of input and output pins ******************/
#define ADMIN_LED_PORT (uint8)'C'
#define GUEST_LED_PORT (uint8)'C'
#define BLOCK_LED_PORT (uint8)'C'

#define ADMIN_LED_PIN  (uint8)0
#define GUEST_LED_PIN  (uint8)1
#define BLOCK_LED_PIN  (uint8)2



#endif /* LED_CONFIGURATION_H_ */