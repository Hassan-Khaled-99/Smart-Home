/*
 * main.h
 *
 * Created: 2/8/2023 1:36:25 PM
 *  Author: eng.m.nagy
 */ 




#ifndef MAIN_H_
#define MAIN_H_

#include "CPU_Configuration.h"
#include "LED_Private.h"
#include "LCD_Private.h"
#include "Key_PAD_Private.h"
#include "menu.h"
#include "menu_Config.h"
#include "EEPROM_Private.h"
#include "SPI_Private.h"


#endif /* MAIN_H_ */