/*
 * SPI_Configuration.h
 *
 * Created: 2/8/2023 12:10:43 PM
 *  Author: eng.m.nagy
 */ 


#ifndef SPI_CONFIGURATION_H_
#define SPI_CONFIGURATION_H_

#include "CPU_Configuration.h"

#define SPI_SCK     7
#define SPI_MISO    6
#define SPI_MOSI    5
#define SPI_SS      4



#endif /* SPI_CONFIGURATION_H_ */