/*
 * STD_type.h
 *
 * Created: 2/8/2023 12:30:31 AM
 *  Author: eng.m.nagy
 */ 


#ifndef STD_TYPE_H_
#define STD_TYPE_H_


typedef unsigned char        uint8;
typedef signed char	         sint8;
typedef unsigned short       uint16;
typedef signed short         sint16;
typedef double               float64;
typedef unsigned long        uint32;


#endif /* STD_TYPE_H_ */