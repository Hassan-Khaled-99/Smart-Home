/*
 * Timer_PWM_Interface.c
 *
 * Created: 2/8/2023 12:09:08 PM
 *  Author: eng.m.nagy
 */ 

#include "Timer_PWM_Private.h"

void timer_initializefastpwm(void)
{
	//Config OCR0
	//OCR0 = the value to compare with
	OCR0 = 128;
	
	//Set timer mode
	//adjust fast pulse width modulation mode
	SET_BIT(TCCR0, WGM00);
	SET_BIT(TCCR0, WGM01);
	
	//Enable global interrupts
	sei();
	
	SET_BIT(TCCR0, COM01); //adjust non inverting mode
	
	//Enable timer0 interrupt for overflow mode
	SET_BIT(TIMSK,TOIE0);
	
	//Configure clock
	//set as clk/1024
	SET_BIT(TCCR0, CS00);
	CLR_BIT(TCCR0, CS01);
	SET_BIT(TCCR0, CS02);
}

