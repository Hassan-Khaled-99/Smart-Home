/*
 * Timer0_Private.h
 *
 * Created: 2/8/2023 12:06:39 PM
 *  Author: eng.m.nagy
 */ 


#ifndef TIMER0_PRIVATE_H_
#define TIMER0_PRIVATE_H_

#include "Timer0_Configuration.h"


void timer0_initializeCTC(void);

void timer0_stop(void);

void change_dutycycle(float64 duty);



#endif /* TIMER0_PRIVATE_H_ */