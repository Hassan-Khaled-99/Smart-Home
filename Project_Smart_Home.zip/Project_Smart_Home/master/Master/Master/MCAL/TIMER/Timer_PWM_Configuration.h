/*
 * Timer_PWM_Configuration.h
 *
 * Created: 2/8/2023 12:08:42 PM
 *  Author: eng.m.nagy
 */ 


#ifndef TIMER_PWM_CONFIGURATION_H_
#define TIMER_PWM_CONFIGURATION_H_

#include "CPU_Configuration.h"



#endif /* TIMER_PWM_CONFIGURATION_H_ */