/*
 * Timer0_Configuration.h
 *
 * Created: 2/8/2023 12:07:43 PM
 *  Author: eng.m.nagy
 */ 


#ifndef TIMER0_CONFIGURATION_H_
#define TIMER0_CONFIGURATION_H_

#include "CPU_Configuration.h"



#endif /* TIMER0_CONFIGURATION_H_ */