/*
 * Timer_PWM_Private.h
 *
 * Created: 2/8/2023 12:08:15 PM
 *  Author: eng.m.nagy
 */ 


#ifndef TIMER_PWM_PRIVATE_H_
#define TIMER_PWM_PRIVATE_H_

#include "Timer_PWM_Configuration.h"

void timer_initializefastpwm(void);



#endif /* TIMER_PWM_PRIVATE_H_ */