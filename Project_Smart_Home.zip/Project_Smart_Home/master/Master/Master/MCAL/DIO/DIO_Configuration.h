/*
 * DIO_Configuration.h
 *
 * Created: 2/8/2023 12:18:55 PM
 *  Author: eng.m.nagy
 */ 


#ifndef DIO_CONFIGURATION_H_
#define DIO_CONFIGURATION_H_

#include "CPU_Configuration.h"



#endif /* DIO_CONFIGURATION_H_ */