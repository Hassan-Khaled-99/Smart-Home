/*
 * EEPROM_Configuration.h
 *
 * Created: 2/8/2023 12:15:58 PM
 *  Author: eng.m.nagy
 */ 


#ifndef EEPROM_CONFIGURATION_H_
#define EEPROM_CONFIGURATION_H_

#include "CPU_Configuration.h"



#endif /* EEPROM_CONFIGURATION_H_ */